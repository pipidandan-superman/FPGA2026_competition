EES-331 SD boot package
Copy every file in boot/ to the SD boot partition together.
PL mode: manual
XSA SHA256: d69fb256b66106da87514fc3821fe177bbe538c128e74485f43a4a265f092ebc
PYNQ camera application: integrated in full IMG
New hardware configuration requires cold-boot and application validation.
