#!/usr/bin/env python3
print("EES-331: PL loading mode manual")
